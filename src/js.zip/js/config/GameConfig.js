// src/js/config/GameConfig.js

export const GameConfig = {
    // Core game settings
    core: {
        tileSize: 64,
        worldSize: {
            width: 100,
            height: 100
        }
    },
    
    // Player settings
    player: {
        classes: {
            bladedancer: {
                hitPoints: 10,
                moveSpeed: 5,
                damageStunDuration: 0.25
            },
            guardian: {
                hitPoints: 3,
                moveSpeed: 3,
                damageStunDuration: 0.3
            },
            hunter: {
                hitPoints: 1,
                moveSpeed: 4,
                damageStunDuration: 0.2
            },
            rogue: {
                hitPoints: 1,
                moveSpeed: 6,
                damageStunDuration: 0.15
            }
        }
    },
    
    // Monster settings
    monsters: {
        types: {
            skeleton: {
                hitPoints: 2,
                moveSpeed: 2,
                attackRange: 70,
                attackDamage: 1,
                collisionRadius: 15,
                aggroRange: 250,
                stunDuration: 0.2,
                attack: {
                    windup: 0.2,
                    duration: 0.4,
                    recovery: 0.6,
                    cooldown: 1.5,
                    pattern: 'cone',
                    color: 0xEEEEEE
                }
            },
            ogre: {
                hitPoints: 4,
                moveSpeed: 1,
                attackRange: 90,
                attackDamage: 2,
                collisionRadius: 25,
                aggroRange: 200,
                stunDuration: 0.3,
                attack: {
                    windup: 0.9,
                    duration: 0.4,
                    recovery: 0.8,
                    cooldown: 3.0,
                    pattern: 'cone',
                    color: 0x885500
                }
            },
            elemental: {
                hitPoints: 3,
                moveSpeed: 1.5,
                attackRange: 120,
                attackDamage: 1,
                collisionRadius: 15,
                aggroRange: 300,
                stunDuration: 0.2,
                attack: {
                    windup: 0.4,
                    duration: 0.6,
                    recovery: 0.5,
                    cooldown: 2.5,
                    pattern: 'circle',
                    color: 0x42C0FB
                }
            },
            ghoul: {
                hitPoints: 2,
                moveSpeed: 2.5,
                attackRange: 60,
                attackDamage: 1,
                collisionRadius: 10,
                aggroRange: 275,
                stunDuration: 0.15,
                attack: {
                    windup: 0.15,
                    duration: 0.25,
                    recovery: 0.3,
                    cooldown: 1.0,
                    pattern: 'cone',
                    color: 0x7CFC00
                }
            }
        },
        spawn: {
            rate: 5,
            maxMonsters: 10,
            minDistanceFromPlayer: 400,
            maxDistanceFromPlayer: 800,
            distribution: {
                skeleton: 0.25,
                ogre: 0.25,
                elemental: 0.25,
                ghoul: 0.25
            },
            enableTestSpawns: true
        }
    },
    
    // Combat settings
    combat: {
        attacks: {
            primary: {
                name: "Slash Attack",
                damage: 1,
                windupTime: 0,
                hitTime: 133,
                recoveryTime: 200,
                cooldown: 100,
                hitboxType: 'rectangle',
                hitboxParams: {
                    width: 45,
                    length: 85
                },
                hitboxVisual: {
                    color: 0xFF5555,
                    fillAlpha: 0.0,
                    lineAlpha: 0.0,
                    lineWidth: 3,
                    duration: 1
                },
                effectSequence: [
                    { type: 'slash_effect', timing: 250 }
                ]
            },
            secondary: {
                name: "Smash Attack",
                damage: 2,
                windupTime: 250,
                hitTime: 500,
                recoveryTime: 300,
                cooldown: 800,
                hitboxType: 'rectangle',
                hitboxParams: {
                    width: 70,
                    length: 110
                },
                hitboxVisual: {
                    color: 0x00FFFF,
                    fillAlpha: 0.01,
                    lineAlpha: 0.0,
                    lineWidth: 3,
                    duration: 0.3
                },
                effectSequence: [
                    { type: 'strike_windup', timing: 100 },
                    { type: 'strike_cast', timing: 500 }
                ]
            }
        },
        effects: {
            slash_effect: {
                scale: 1.5,
                offsetDistance: 60,
                rotationOffset: 2 * Math.PI,
                animationSpeed: 0.5,
                followDuration: 0,
                flipX: false,
                flipY: true
            },
            strike_windup: {
                scale: 1.5,
                offsetDistance: 10,
                rotationOffset: 0,
                animationSpeed: 0.4,
                followDuration: 0,
                flipX: false,
                flipY: false
            },
            strike_cast: {
                scale: 1.3,
                offsetDistance: 70,
                rotationOffset: Math.PI / 2,
                animationSpeed: 0.4,
                followDuration: 0,
                flipX: false,
                flipY: false
            }
        }
    },
    
    // Physics settings
    physics: {
        characterRadius: 20,
        tileCollisionBuffer: 0.85,
        northBufferMultiplier: 1.1,
        southBufferMultiplier: 0.5
    },
    
    // UI settings
    ui: {
        health: {
            position: { x: 20, y: 20 },
            heartSize: 8,
            heartSpacing: 25,
            colors: {
                full: 0xE73C3C,
                empty: 0x666666
            }
        }
    }
};